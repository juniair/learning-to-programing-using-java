package stackcalculator;

import java.util.ArrayList;
import java.util.Stack;

public class StackCalculator {
	public String getCalculate(String content) {
        char[] operationCode = {'+', '-', '*', '/', '(', ')'};
        
        ArrayList<String> postfixList = new ArrayList<String>(); // 후위표기법으로 변환 후 저장 할 ArrayList
        MyStack<Character> opStack = new MyStack<Character>(); // 연산 부호 우선순위처리 하며 후위 표기법으로 변경하는 Stack
        MyStack<String> calculatorStack = new MyStack<String>(); // 후위 표기법을 계산하는 Stack

        int index = 0;

        for (int i = 0; i < content.length(); i++) {
            for (int j = 0; j < operationCode.length; j++) {
                if (content.charAt(i) == operationCode[j]) {
                    postfixList.add(content.substring(index, i).trim().replace("(", "").replace(")", ""));
                    if (opStack.isEmpty()) {
                        opStack.push(operationCode[j]);
                    } else {
                        if (opOrder(operationCode[j]) > opOrder((char) opStack.peek())) {
                            opStack.push(operationCode[j]);
                        } else if (opOrder(operationCode[j]) <= opOrder((char) opStack.peek())) {
                            postfixList.add(opStack.peek().toString());
                            opStack.pop();
                            opStack.push(operationCode[j]);
                        }
                    }
                    index = i + 1;
                }
            }
        }

        postfixList.add(content.substring(index, content.length()).trim().replace("(", "").replace(")", ""));

        if (!opStack.isEmpty()) {
            for (int i = 0; i < opStack.size(); i++) {
                postfixList.add(opStack.peek().toString());
                opStack.pop();
            }
        }

        // 공백, 괄호 제거
        for (int i = 0; i < postfixList.size(); i++) {
            if (postfixList.get(i).equals("")) {
                postfixList.remove(i);
                i = i - 1;
            } else if (postfixList.get(i).equals("(")) {
                postfixList.remove(i);
                i = i - 1;
            } else if (postfixList.get(i).equals(")")) {
                postfixList.remove(i);
                i = i - 1;
            }
        }

        // 후위연산 처리
        for (int i = 0; i < postfixList.size(); i++) {
            calculatorStack.push(postfixList.get(i));
            for (int j = 0; j < operationCode.length; j++) {
                if (postfixList.get(i).charAt(0) == operationCode[j]) {
                    calculatorStack.pop();
                    int num1, num2;
                    String result;

                    num1 = Integer.parseInt((String) calculatorStack.pop());
                    num2 = Integer.parseInt((String) calculatorStack.pop());

                    switch (operationCode[j]) {
                        case '+':
                        	result = String.valueOf(num1 + num2);
                            calculatorStack.push(result);
                            break;
                        case '-':
                        	result = String.valueOf(num1 - num2);
                            calculatorStack.push(result);
                            break;
                        case '*':
                        	result = String.valueOf(num1 * num2);
                            calculatorStack.push(result);
                            break;
                        case '/':
                        	result = String.valueOf(num1 / num2);
                            calculatorStack.push(result);
                            break;
                    }
                }
            }
        }
		return (String) calculatorStack.pop();
    }

    public static int opOrder(char op) {
        switch (op) {
            case '+':
            case '-':
                return 1;
            case '*':
            case '/':
                return 2;
            default:
                return -1;
        }
    }
}

