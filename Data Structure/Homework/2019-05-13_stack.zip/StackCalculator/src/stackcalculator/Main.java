package stackcalculator;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner Scanner = new Scanner(System.in);
		StackCalculator StackCalculator = new StackCalculator();

		System.out.print("입력 :");
		String input = Scanner.nextLine();
		
		System.out.println("결과 : " + StackCalculator.getCalculate(input));
		System.out.println();
	}
}
